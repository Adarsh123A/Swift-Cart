import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"

interface FoodCategoryProps {
  id: number
  name: string
  icon: string
  color: string
}

interface FoodCategoryCardProps {
  category: FoodCategoryProps
}

export default function FoodCategoryCard({ category }: FoodCategoryCardProps) {
  const { id, name, icon, color } = category

  return (
    <Link href={`/food/category/${id}`}>
      <Card className="transition-all duration-300 hover:border-primary hover:shadow-md">
        <CardContent className="flex flex-col items-center justify-center p-4 text-center">
          <div className={`mb-2 flex h-12 w-12 items-center justify-center rounded-full ${color}`}>
            <span className="text-2xl">{icon}</span>
          </div>
          <span className="text-sm font-medium">{name}</span>
        </CardContent>
      </Card>
    </Link>
  )
}
