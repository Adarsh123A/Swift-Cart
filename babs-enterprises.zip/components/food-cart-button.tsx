"use client"

import Link from "next/link"
import { ShoppingBag } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useFoodCart } from "@/lib/food-cart-context"

export default function FoodCartButton() {
  const { totalFoodItems } = useFoodCart()

  return (
    <Link href="/food/cart">
      <Button variant="ghost" size="icon" aria-label="Food Cart" className="relative">
        <ShoppingBag className="h-5 w-5" />
        {totalFoodItems > 0 && (
          <span className="absolute -right-1 -top-1 flex h-4 w-4 items-center justify-center rounded-full bg-primary text-[10px] font-medium text-primary-foreground">
            {totalFoodItems}
          </span>
        )}
      </Button>
    </Link>
  )
}
