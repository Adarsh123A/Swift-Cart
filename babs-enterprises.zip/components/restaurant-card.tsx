import Image from "next/image"
import Link from "next/link"
import { Star, Clock, DollarSign } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

interface RestaurantProps {
  id: number
  name: string
  image: string
  cuisine?: string
  type?: string
  rating: number
  deliveryTime: string
  deliveryFee: number
  minOrder: number
}

interface RestaurantCardProps {
  restaurant: RestaurantProps
  type: "restaurant" | "grocery"
}

export default function RestaurantCard({ restaurant, type }: RestaurantCardProps) {
  const { id, name, image, cuisine, type: storeType, rating, deliveryTime, deliveryFee, minOrder } = restaurant

  const href = type === "restaurant" ? `/food/restaurant/${id}` : `/food/grocery/${id}`

  return (
    <Link href={href}>
      <Card className="overflow-hidden transition-all duration-300 hover:shadow-md">
        <div className="relative h-40 w-full">
          <Image src={image || "/placeholder.svg"} alt={name} fill className="object-cover" />
          {deliveryFee === 0 && <Badge className="absolute right-2 top-2">Free Delivery</Badge>}
        </div>
        <CardContent className="p-4">
          <h3 className="font-medium">{name}</h3>
          <p className="text-sm text-muted-foreground">{type === "restaurant" ? cuisine : storeType}</p>

          <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-sm">
            <div className="flex items-center">
              <Star className="mr-1 h-4 w-4 fill-yellow-400 text-yellow-400" />
              <span>{rating}</span>
            </div>
            <div className="flex items-center">
              <Clock className="mr-1 h-4 w-4 text-muted-foreground" />
              <span>{deliveryTime}</span>
            </div>
            <div className="flex items-center">
              <DollarSign className="mr-1 h-4 w-4 text-muted-foreground" />
              <span>Min ₹{(minOrder * 80).toFixed(0)}</span>
            </div>
          </div>

          <div className="mt-2 text-sm">
            <span className={deliveryFee === 0 ? "text-green-500" : ""}>
              {deliveryFee === 0 ? "Free Delivery" : `₹${(deliveryFee * 80).toFixed(2)} Delivery Fee`}
            </span>
          </div>
        </CardContent>
      </Card>
    </Link>
  )
}
