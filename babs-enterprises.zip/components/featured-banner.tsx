"use client"

import { useState, useEffect } from "react"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function FeaturedBanner() {
  const [current, setCurrent] = useState(0)

  const banners = [
    {
      id: 1,
      title: "New Arrivals",
      description: "Check out our latest tech gadgets",
      cta: "Shop Now",
      link: "/category/electronics",
      color: "from-blue-900/50 to-purple-900/50",
    },
    {
      id: 2,
      title: "Summer Sale",
      description: "Up to 50% off on selected items",
      cta: "View Deals",
      link: "/deals",
      color: "from-pink-900/50 to-orange-900/50",
    },
    {
      id: 3,
      title: "Premium Collection",
      description: "Discover our exclusive premium products",
      cta: "Explore",
      link: "/premium",
      color: "from-emerald-900/50 to-cyan-900/50",
    },
  ]

  const next = () => {
    setCurrent((current + 1) % banners.length)
  }

  const prev = () => {
    setCurrent((current - 1 + banners.length) % banners.length)
  }

  // Auto-rotate banners
  useEffect(() => {
    const interval = setInterval(() => {
      next()
    }, 5000)
    return () => clearInterval(interval)
  }, [current])

  return (
    <div className="relative overflow-hidden rounded-xl">
      <div
        className="flex transition-transform duration-500 ease-in-out"
        style={{ transform: `translateX(-${current * 100}%)` }}
      >
        {banners.map((banner) => (
          <div key={banner.id} className={`min-w-full rounded-xl bg-gradient-to-r ${banner.color} p-8 md:p-12`}>
            <div className="flex flex-col items-start justify-between gap-4 md:flex-row md:items-center">
              <div>
                <h2 className="text-2xl font-bold md:text-3xl">{banner.title}</h2>
                <p className="mt-2 text-muted-foreground">{banner.description}</p>
              </div>
              <Button asChild size="lg" className="shrink-0">
                <Link href={banner.link}>{banner.cta}</Link>
              </Button>
            </div>
          </div>
        ))}
      </div>

      {/* Navigation buttons */}
      <div className="absolute inset-0 flex items-center justify-between p-4">
        <Button
          variant="ghost"
          size="icon"
          className="h-8 w-8 rounded-full bg-background/20 backdrop-blur-sm hover:bg-background/40"
          onClick={prev}
        >
          <ChevronLeft className="h-4 w-4" />
          <span className="sr-only">Previous banner</span>
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="h-8 w-8 rounded-full bg-background/20 backdrop-blur-sm hover:bg-background/40"
          onClick={next}
        >
          <ChevronRight className="h-4 w-4" />
          <span className="sr-only">Next banner</span>
        </Button>
      </div>

      {/* Indicators */}
      <div className="absolute bottom-4 left-1/2 flex -translate-x-1/2 gap-2">
        {banners.map((_, index) => (
          <button
            key={index}
            className={`h-2 w-2 rounded-full ${current === index ? "bg-primary" : "bg-background/50"}`}
            onClick={() => setCurrent(index)}
          >
            <span className="sr-only">Banner {index + 1}</span>
          </button>
        ))}
      </div>
    </div>
  )
}
