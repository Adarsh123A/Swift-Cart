"use client"

import type { ReactNode } from "react"
import { CartProvider } from "@/lib/cart-context"
import { FoodCartProvider } from "@/lib/food-cart-context"

export function Providers({ children }: { children: ReactNode }) {
  return (
    <CartProvider>
      <FoodCartProvider>{children}</FoodCartProvider>
    </CartProvider>
  )
}
