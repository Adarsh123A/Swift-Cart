"use client"

import type React from "react"

import { useState } from "react"
import { Package, Search, CheckCircle, Clock, Truck, Box } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useToast } from "@/hooks/use-toast"

export default function TrackOrderPage() {
  const [orderNumber, setOrderNumber] = useState("")
  const [isTracking, setIsTracking] = useState(false)
  const [trackingResult, setTrackingResult] = useState<null | {
    orderNumber: string
    status: "processing" | "shipped" | "delivered"
    date: string
    estimatedDelivery: string
    items: number
  }>(null)

  const { toast } = useToast()

  const handleTrackOrder = (e: React.FormEvent) => {
    e.preventDefault()

    if (!orderNumber) {
      toast({
        title: "Error",
        description: "Please enter an order number.",
        variant: "destructive",
      })
      return
    }

    setIsTracking(true)

    // Simulate API call
    setTimeout(() => {
      setIsTracking(false)

      // Mock tracking result
      if (orderNumber === "12345") {
        setTrackingResult({
          orderNumber: "12345",
          status: "shipped",
          date: "April 1, 2025",
          estimatedDelivery: "April 5, 2025",
          items: 3,
        })
      } else if (orderNumber === "54321") {
        setTrackingResult({
          orderNumber: "54321",
          status: "delivered",
          date: "March 25, 2025",
          estimatedDelivery: "March 30, 2025",
          items: 2,
        })
      } else if (orderNumber === "67890") {
        setTrackingResult({
          orderNumber: "67890",
          status: "processing",
          date: "April 3, 2025",
          estimatedDelivery: "April 8, 2025",
          items: 1,
        })
      } else {
        toast({
          title: "Order Not Found",
          description: "We couldn't find an order with that number. Try 12345, 54321, or 67890 for demo purposes.",
          variant: "destructive",
        })
        setTrackingResult(null)
      }
    }, 1500)
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "processing":
        return <Clock className="h-8 w-8 text-amber-500" />
      case "shipped":
        return <Truck className="h-8 w-8 text-blue-500" />
      case "delivered":
        return <CheckCircle className="h-8 w-8 text-green-500" />
      default:
        return <Box className="h-8 w-8" />
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case "processing":
        return "Your order is being processed"
      case "shipped":
        return "Your order is on its way"
      case "delivered":
        return "Your order has been delivered"
      default:
        return "Unknown status"
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mx-auto max-w-2xl">
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-bold">Track Your Order</h1>
          <p className="mt-2 text-muted-foreground">Enter your order number to check the status of your shipment</p>
        </div>

        <div className="rounded-lg border p-6 shadow-sm">
          <form onSubmit={handleTrackOrder} className="space-y-4">
            <div className="flex flex-col gap-4 sm:flex-row">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Enter order number (e.g., 12345)"
                  value={orderNumber}
                  onChange={(e) => setOrderNumber(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Button type="submit" disabled={isTracking}>
                {isTracking ? "Tracking..." : "Track Order"}
              </Button>
            </div>

            <p className="text-center text-sm text-muted-foreground">
              Try order numbers: 12345, 54321, or 67890 for demo purposes
            </p>
          </form>

          {trackingResult && (
            <div className="mt-8 space-y-6">
              <div className="flex items-center justify-between rounded-lg bg-muted p-4">
                <div>
                  <p className="text-sm text-muted-foreground">Order Number</p>
                  <p className="font-medium">#{trackingResult.orderNumber}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Order Date</p>
                  <p className="font-medium">{trackingResult.date}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Items</p>
                  <p className="font-medium">{trackingResult.items}</p>
                </div>
              </div>

              <div className="rounded-lg border p-6">
                <div className="flex flex-col items-center gap-4 sm:flex-row">
                  {getStatusIcon(trackingResult.status)}
                  <div className="text-center sm:text-left">
                    <h3 className="text-xl font-semibold">{getStatusText(trackingResult.status)}</h3>
                    <p className="text-muted-foreground">
                      {trackingResult.status === "delivered"
                        ? `Delivered on ${trackingResult.estimatedDelivery}`
                        : `Estimated delivery: ${trackingResult.estimatedDelivery}`}
                    </p>
                  </div>
                </div>

                <div className="mt-8">
                  <div className="relative">
                    <div className="absolute left-0 top-1/2 h-1 w-full -translate-y-1/2 rounded-full bg-muted">
                      <div
                        className={`h-1 rounded-full bg-primary transition-all ${
                          trackingResult.status === "processing"
                            ? "w-1/3"
                            : trackingResult.status === "shipped"
                              ? "w-2/3"
                              : "w-full"
                        }`}
                      ></div>
                    </div>

                    <div className="relative flex justify-between pt-6">
                      <div className="flex flex-col items-center">
                        <div
                          className={`flex h-8 w-8 items-center justify-center rounded-full border-2 ${
                            trackingResult.status
                              ? "border-primary bg-primary text-primary-foreground"
                              : "border-muted-foreground"
                          }`}
                        >
                          <CheckCircle className="h-4 w-4" />
                        </div>
                        <span className="mt-2 text-sm font-medium">Ordered</span>
                      </div>

                      <div className="flex flex-col items-center">
                        <div
                          className={`flex h-8 w-8 items-center justify-center rounded-full border-2 ${
                            trackingResult.status === "shipped" || trackingResult.status === "delivered"
                              ? "border-primary bg-primary text-primary-foreground"
                              : "border-muted-foreground"
                          }`}
                        >
                          <Package className="h-4 w-4" />
                        </div>
                        <span className="mt-2 text-sm font-medium">Shipped</span>
                      </div>

                      <div className="flex flex-col items-center">
                        <div
                          className={`flex h-8 w-8 items-center justify-center rounded-full border-2 ${
                            trackingResult.status === "delivered"
                              ? "border-primary bg-primary text-primary-foreground"
                              : "border-muted-foreground"
                          }`}
                        >
                          <Truck className="h-4 w-4" />
                        </div>
                        <span className="mt-2 text-sm font-medium">Delivered</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <p className="text-center text-sm text-muted-foreground">
                This is a mock order tracking system for a school project. No real orders are being tracked.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
