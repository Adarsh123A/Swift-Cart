import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, SlidersHorizontal } from "lucide-react"
import ProductCard from "@/components/product-card"

export default function ProductsPage() {
  // Mock products data
  const products = [
    {
      id: 1,
      name: "Premium Wireless Headphones",
      price: 199.99, // Base price in USD, displayed in INR
      image: "/placeholder.svg?height=300&width=300",
      category: "Electronics",
      inStock: true,
    },
    {
      id: 2,
      name: "Smart Fitness Watch",
      price: 149.99,
      image: "/placeholder.svg?height=300&width=300",
      category: "Electronics",
      inStock: true,
    },
    {
      id: 3,
      name: "Designer Backpack",
      price: 89.99,
      image: "/placeholder.svg?height=300&width=300",
      category: "Fashion",
      inStock: false,
    },
    {
      id: 4,
      name: "Portable Bluetooth Speaker",
      price: 79.99,
      image: "/placeholder.svg?height=300&width=300",
      category: "Electronics",
      inStock: true,
    },
    {
      id: 5,
      name: "Ultra HD Smart TV",
      price: 899.99,
      image: "/placeholder.svg?height=300&width=300",
      category: "Electronics",
      inStock: true,
    },
    {
      id: 6,
      name: "Ergonomic Office Chair",
      price: 249.99,
      image: "/placeholder.svg?height=300&width=300",
      category: "Home Office",
      inStock: true,
    },
    {
      id: 7,
      name: "Wireless Gaming Mouse",
      price: 59.99,
      image: "/placeholder.svg?height=300&width=300",
      category: "Gaming",
      inStock: true,
    },
    {
      id: 8,
      name: "Mechanical Keyboard",
      price: 129.99,
      image: "/placeholder.svg?height=300&width=300",
      category: "Gaming",
      inStock: false,
    },
    {
      id: 9,
      name: "Professional DSLR Camera",
      price: 1299.99,
      image: "/placeholder.svg?height=300&width=300",
      category: "Electronics",
      inStock: true,
    },
    {
      id: 10,
      name: "Leather Wallet",
      price: 49.99,
      image: "/placeholder.svg?height=300&width=300",
      category: "Fashion",
      inStock: true,
    },
    {
      id: 11,
      name: "Stainless Steel Water Bottle",
      price: 24.99,
      image: "/placeholder.svg?height=300&width=300",
      category: "Sports",
      inStock: true,
    },
    {
      id: 12,
      name: "Wireless Earbuds",
      price: 129.99,
      image: "/placeholder.svg?height=300&width=300",
      category: "Electronics",
      inStock: true,
    },
  ]

  // Categories
  const categories = ["All Categories", "Electronics", "Fashion", "Home Office", "Gaming", "Sports"]

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="mb-4 text-3xl font-bold">All Products</h1>
        <p className="text-muted-foreground">Browse our collection of high-quality products</p>
      </div>

      <div className="mb-8 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div className="relative w-full md:max-w-sm">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input type="search" placeholder="Search products..." className="pl-10" />
        </div>

        <div className="flex flex-wrap items-center gap-4">
          <Select defaultValue="featured">
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="featured">Featured</SelectItem>
              <SelectItem value="price-low">Price: Low to High</SelectItem>
              <SelectItem value="price-high">Price: High to Low</SelectItem>
              <SelectItem value="newest">Newest First</SelectItem>
            </SelectContent>
          </Select>

          <Select defaultValue="all">
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Category" />
            </SelectTrigger>
            <SelectContent>
              {categories.map((category) => (
                <SelectItem key={category} value={category.toLowerCase().replace(" ", "-")}>
                  {category}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Button variant="outline" size="icon">
            <SlidersHorizontal className="h-4 w-4" />
            <span className="sr-only">Filters</span>
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
        {products.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>

      <div className="mt-12 flex justify-center">
        <Button variant="outline">Load More</Button>
      </div>
    </div>
  )
}
