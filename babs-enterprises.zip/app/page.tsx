import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Search } from "lucide-react"
import Link from "next/link"
import FeaturedBanner from "@/components/featured-banner"
import ProductCard from "@/components/product-card"

export default function Home() {
  // Mock featured products
  const featuredProducts = [
    {
      id: 1,
      name: "Premium Wireless Headphones",
      price: 199.99,
      image: "/placeholder.svg?height=300&width=300",
      category: "Electronics",
      inStock: true,
    },
    {
      id: 2,
      name: "Smart Fitness Watch",
      price: 149.99,
      image: "/placeholder.svg?height=300&width=300",
      category: "Electronics",
      inStock: true,
    },
    {
      id: 3,
      name: "Designer Backpack",
      price: 89.99,
      image: "/placeholder.svg?height=300&width=300",
      category: "Fashion",
      inStock: false,
    },
    {
      id: 4,
      name: "Portable Bluetooth Speaker",
      price: 79.99,
      image: "/placeholder.svg?height=300&width=300",
      category: "Electronics",
      inStock: true,
    },
  ]

  // Mock trending products
  const trendingProducts = [
    {
      id: 5,
      name: "Ultra HD Smart TV",
      price: 899.99,
      image: "/placeholder.svg?height=300&width=300",
      category: "Electronics",
      inStock: true,
    },
    {
      id: 6,
      name: "Ergonomic Office Chair",
      price: 249.99,
      image: "/placeholder.svg?height=300&width=300",
      category: "Home Office",
      inStock: true,
    },
    {
      id: 7,
      name: "Wireless Gaming Mouse",
      price: 59.99,
      image: "/placeholder.svg?height=300&width=300",
      category: "Gaming",
      inStock: true,
    },
    {
      id: 8,
      name: "Mechanical Keyboard",
      price: 129.99,
      image: "/placeholder.svg?height=300&width=300",
      category: "Gaming",
      inStock: false,
    },
  ]

  // Categories
  const categories = ["Electronics", "Fashion", "Home Office", "Gaming", "Beauty", "Sports", "Books", "Toys"]

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Hero section with search */}
      <div className="mb-12 flex flex-col items-center justify-center space-y-6 text-center">
        <h1 className="text-4xl font-bold tracking-tight sm:text-5xl md:text-6xl">
          <span className="bg-gradient-to-r from-purple-400 to-pink-600 bg-clip-text text-transparent">Swift</span> Cart
        </h1>
        <p className="max-w-[700px] text-lg text-muted-foreground">
          Discover premium products at competitive prices. Your one-stop shop for all your needs.
        </p>
        <div className="relative w-full max-w-md">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input type="search" placeholder="Search for products..." className="pl-10" />
        </div>
      </div>

      {/* Featured banners */}
      <FeaturedBanner />

      {/* Categories */}
      <div className="my-12">
        <h2 className="mb-6 text-2xl font-bold">Shop by Category</h2>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 md:grid-cols-8">
          {categories.map((category) => (
            <Link key={category} href={`/category/${category.toLowerCase()}`} className="group">
              <Card className="transition-all duration-300 hover:border-primary hover:shadow-md">
                <CardContent className="flex flex-col items-center justify-center p-4 text-center">
                  <div className="mb-2 h-12 w-12 rounded-full bg-muted/50 p-2"></div>
                  <span className="text-sm font-medium group-hover:text-primary">{category}</span>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </div>

      {/* Products tabs */}
      <div className="my-12">
        <Tabs defaultValue="featured" className="w-full">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold">Our Products</h2>
            <TabsList>
              <TabsTrigger value="featured">Featured</TabsTrigger>
              <TabsTrigger value="trending">Trending</TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="featured" className="mt-6">
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
              {featuredProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="trending" className="mt-6">
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
              {trendingProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Food & Grocery section */}
      <div className="my-12">
        <div className="mb-6 flex items-center justify-between">
          <h2 className="text-2xl font-bold">Food & Grocery Delivery</h2>
          <Button variant="outline" asChild>
            <Link href="/food">View All</Link>
          </Button>
        </div>

        <div className="rounded-xl bg-gradient-to-r from-purple-900/50 to-pink-900/50 p-8">
          <div className="flex flex-col items-center justify-between gap-6 md:flex-row">
            <div>
              <h3 className="text-xl font-bold sm:text-2xl">Hungry? We deliver!</h3>
              <p className="mt-2 max-w-md text-muted-foreground">
                Order food from your favorite restaurants or get groceries delivered to your door in minutes.
              </p>
              <Button className="mt-4" asChild>
                <Link href="/food">Order Now</Link>
              </Button>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="h-24 w-24 rounded-lg bg-background/10 backdrop-blur-sm"></div>
              <div className="h-24 w-24 rounded-lg bg-background/10 backdrop-blur-sm"></div>
              <div className="h-24 w-24 rounded-lg bg-background/10 backdrop-blur-sm"></div>
              <div className="h-24 w-24 rounded-lg bg-background/10 backdrop-blur-sm"></div>
            </div>
          </div>
        </div>
      </div>

      {/* Call to action */}
      <div className="my-16 rounded-xl bg-gradient-to-r from-purple-900/50 to-pink-900/50 p-8 text-center">
        <h2 className="mb-4 text-3xl font-bold">Join Our Community</h2>
        <p className="mb-6 text-lg text-muted-foreground">
          Sign up today and get exclusive access to special offers and new arrivals.
        </p>
        <Button size="lg" asChild>
          <Link href="/signup">Sign Up Now</Link>
        </Button>
      </div>
    </div>
  )
}
