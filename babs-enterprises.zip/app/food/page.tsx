import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Search, MapPin, Clock } from "lucide-react"
import Link from "next/link"
import RestaurantCard from "@/components/restaurant-card"
import FoodCategoryCard from "@/components/food-category-card"

export default function FoodPage() {
  // Mock restaurants data
  const restaurants = [
    {
      id: 1,
      name: "Burger Palace",
      image: "/placeholder.svg?height=200&width=300",
      cuisine: "American",
      rating: 4.7,
      deliveryTime: "15-25 min",
      deliveryFee: 2.99, // Base price in USD, displayed in INR
      minOrder: 10, // Base price in USD, displayed in INR
    },
    {
      id: 2,
      name: "Pizza Heaven",
      image: "/placeholder.svg?height=200&width=300",
      cuisine: "Italian",
      rating: 4.5,
      deliveryTime: "20-30 min",
      deliveryFee: 1.99,
      minOrder: 15,
    },
    {
      id: 3,
      name: "Sushi Express",
      image: "/placeholder.svg?height=200&width=300",
      cuisine: "Japanese",
      rating: 4.8,
      deliveryTime: "25-35 min",
      deliveryFee: 3.99,
      minOrder: 20,
    },
    {
      id: 4,
      name: "Taco Fiesta",
      image: "/placeholder.svg?height=200&width=300",
      cuisine: "Mexican",
      rating: 4.3,
      deliveryTime: "20-30 min",
      deliveryFee: 2.49,
      minOrder: 12,
    },
  ]

  // Mock grocery stores data
  const groceryStores = [
    {
      id: 101,
      name: "Fresh Market",
      image: "/placeholder.svg?height=200&width=300",
      type: "Supermarket",
      rating: 4.6,
      deliveryTime: "30-45 min",
      deliveryFee: 3.99, // Base price in USD, displayed in INR
      minOrder: 25, // Base price in USD, displayed in INR
    },
    {
      id: 102,
      name: "Organic Valley",
      image: "/placeholder.svg?height=200&width=300",
      type: "Organic",
      rating: 4.8,
      deliveryTime: "35-50 min",
      deliveryFee: 4.99,
      minOrder: 30,
    },
    {
      id: 103,
      name: "Quick Mart",
      image: "/placeholder.svg?height=200&width=300",
      type: "Convenience",
      rating: 4.2,
      deliveryTime: "15-25 min",
      deliveryFee: 2.49,
      minOrder: 15,
    },
    {
      id: 104,
      name: "Farmers' Market",
      image: "/placeholder.svg?height=200&width=300",
      type: "Local Produce",
      rating: 4.9,
      deliveryTime: "40-60 min",
      deliveryFee: 5.99,
      minOrder: 35,
    },
  ]

  // Food categories
  const foodCategories = [
    { id: 1, name: "Pizza", icon: "🍕", color: "bg-red-500" },
    { id: 2, name: "Burgers", icon: "🍔", color: "bg-amber-500" },
    { id: 3, name: "Sushi", icon: "🍣", color: "bg-blue-500" },
    { id: 4, name: "Tacos", icon: "🌮", color: "bg-green-500" },
    { id: 5, name: "Salads", icon: "🥗", color: "bg-emerald-500" },
    { id: 6, name: "Desserts", icon: "🍰", color: "bg-pink-500" },
    { id: 7, name: "Breakfast", icon: "🍳", color: "bg-yellow-500" },
    { id: 8, name: "Coffee", icon: "☕", color: "bg-brown-500" },
  ]

  // Grocery categories
  const groceryCategories = [
    { id: 101, name: "Fruits & Vegetables", icon: "🥬", color: "bg-green-500" },
    { id: 102, name: "Dairy & Eggs", icon: "🥛", color: "bg-blue-100" },
    { id: 103, name: "Meat & Seafood", icon: "🥩", color: "bg-red-300" },
    { id: 104, name: "Bakery", icon: "🍞", color: "bg-amber-200" },
    { id: 105, name: "Frozen Foods", icon: "🧊", color: "bg-blue-300" },
    { id: 106, name: "Snacks", icon: "🍿", color: "bg-yellow-300" },
    { id: 107, name: "Beverages", icon: "🥤", color: "bg-purple-300" },
    { id: 108, name: "Household", icon: "🧹", color: "bg-gray-300" },
  ]

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Hero section with search */}
      <div className="mb-8 rounded-xl bg-gradient-to-r from-purple-900/50 to-pink-900/50 p-8">
        <div className="mx-auto max-w-2xl text-center">
          <h1 className="mb-4 text-3xl font-bold sm:text-4xl">Food & Grocery Delivery</h1>
          <p className="mb-6 text-muted-foreground">
            Order food from your favorite restaurants or groceries delivered to your door
          </p>
          <div className="flex flex-col gap-4 sm:flex-row">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input type="search" placeholder="Search for restaurants or grocery stores" className="pl-10" />
            </div>
            <div className="relative flex-1">
              <MapPin className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input type="text" placeholder="Delivery address" className="pl-10" defaultValue="123 Main St, Anytown" />
            </div>
            <Button>Find Food</Button>
          </div>
        </div>
      </div>

      {/* Main content */}
      <Tabs defaultValue="restaurants" className="w-full">
        <TabsList className="mb-6 grid w-full grid-cols-2">
          <TabsTrigger value="restaurants">Restaurants</TabsTrigger>
          <TabsTrigger value="groceries">Groceries</TabsTrigger>
        </TabsList>

        <TabsContent value="restaurants">
          {/* Food categories */}
          <div className="mb-8">
            <h2 className="mb-4 text-2xl font-bold">Categories</h2>
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-4 md:grid-cols-8">
              {foodCategories.map((category) => (
                <FoodCategoryCard key={category.id} category={category} />
              ))}
            </div>
          </div>

          {/* Featured restaurants */}
          <div className="mb-8">
            <h2 className="mb-4 text-2xl font-bold">Featured Restaurants</h2>
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {restaurants.map((restaurant) => (
                <RestaurantCard key={restaurant.id} restaurant={restaurant} type="restaurant" />
              ))}
            </div>
          </div>

          {/* Popular near you */}
          <div className="mb-8">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-2xl font-bold">Popular Near You</h2>
              <Button variant="link" asChild>
                <Link href="/food/restaurants">View All</Link>
              </Button>
            </div>
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {[...restaurants].reverse().map((restaurant) => (
                <RestaurantCard key={restaurant.id} restaurant={restaurant} type="restaurant" />
              ))}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="groceries">
          {/* Grocery categories */}
          <div className="mb-8">
            <h2 className="mb-4 text-2xl font-bold">Categories</h2>
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-4 md:grid-cols-8">
              {groceryCategories.map((category) => (
                <FoodCategoryCard key={category.id} category={category} />
              ))}
            </div>
          </div>

          {/* Grocery stores */}
          <div className="mb-8">
            <h2 className="mb-4 text-2xl font-bold">Grocery Stores</h2>
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {groceryStores.map((store) => (
                <RestaurantCard key={store.id} restaurant={store} type="grocery" />
              ))}
            </div>
          </div>

          {/* Quick delivery */}
          <div className="mb-8">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-2xl font-bold">Quick Delivery</h2>
              <Button variant="link" asChild>
                <Link href="/food/groceries">View All</Link>
              </Button>
            </div>
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {[groceryStores[2], groceryStores[0], groceryStores[3], groceryStores[1]].map((store) => (
                <RestaurantCard key={store.id} restaurant={store} type="grocery" />
              ))}
            </div>
          </div>
        </TabsContent>
      </Tabs>

      {/* How it works */}
      <div className="my-16 rounded-xl border p-8">
        <h2 className="mb-8 text-center text-2xl font-bold">How It Works</h2>
        <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
          <div className="flex flex-col items-center text-center">
            <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10 text-primary">
              <Search className="h-8 w-8" />
            </div>
            <h3 className="mb-2 text-lg font-medium">Browse & Select</h3>
            <p className="text-muted-foreground">Browse restaurants or grocery stores and select your items</p>
          </div>
          <div className="flex flex-col items-center text-center">
            <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10 text-primary">
              <Clock className="h-8 w-8" />
            </div>
            <h3 className="mb-2 text-lg font-medium">Schedule Delivery</h3>
            <p className="text-muted-foreground">Choose delivery time and provide delivery instructions</p>
          </div>
          <div className="flex flex-col items-center text-center">
            <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10 text-primary">
              <MapPin className="h-8 w-8" />
            </div>
            <h3 className="mb-2 text-lg font-medium">Get Delivery</h3>
            <p className="text-muted-foreground">Track your order in real-time and enjoy your delivery</p>
          </div>
        </div>
      </div>

      {/* Download app banner */}
      <div className="rounded-xl bg-gradient-to-r from-purple-900/50 to-pink-900/50 p-8">
        <div className="flex flex-col items-center justify-between gap-8 md:flex-row">
          <div>
            <h2 className="mb-2 text-2xl font-bold">Get the Swift Cart App</h2>
            <p className="mb-4 text-muted-foreground">Order food and groceries on the go with our mobile app</p>
            <div className="flex flex-wrap gap-4">
              <Button variant="secondary">
                <span className="mr-2">🍎</span> App Store
              </Button>
              <Button variant="secondary">
                <span className="mr-2">🤖</span> Google Play
              </Button>
            </div>
          </div>
          <div className="h-40 w-40 rounded-xl bg-background/10 backdrop-blur-sm"></div>
        </div>
      </div>
    </div>
  )
}
