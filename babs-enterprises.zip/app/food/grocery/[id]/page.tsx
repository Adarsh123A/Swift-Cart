"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Star, Clock, DollarSign, MapPin, Plus, Minus, Heart, Share2, Search } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Separator } from "@/components/ui/separator"
import { useToast } from "@/hooks/use-toast"
import { useFoodCart } from "@/lib/food-cart-context"

// Mock grocery store data
const store = {
  id: 101,
  name: "Fresh Market",
  image: "/placeholder.svg?height=300&width=800",
  type: "Supermarket",
  rating: 4.6,
  reviewCount: 187,
  deliveryTime: "30-45 min",
  deliveryFee: 3.99, // Base price in USD, displayed in INR
  minOrder: 25, // Base price in USD, displayed in INR
  address: "456 Oak St, Anytown",
  description:
    "Your neighborhood grocery store with fresh produce, quality meats, and everyday essentials at competitive prices.",
  hours: "8:00 AM - 10:00 PM",
  isOpen: true,
}

// Mock product categories
const productCategories = [
  { id: 1, name: "Popular Items" },
  { id: 2, name: "Fruits & Vegetables" },
  { id: 3, name: "Dairy & Eggs" },
  { id: 4, name: "Meat & Seafood" },
  { id: 5, name: "Bakery" },
  { id: 6, name: "Beverages" },
]

// Mock products
const products = [
  {
    id: 201,
    name: "Organic Bananas",
    description: "Bunch of 5-7 organic bananas.",
    price: 2.99,
    unit: "bunch",
    image: "/placeholder.svg?height=150&width=150",
    categoryId: 2,
    popular: true,
  },
  {
    id: 202,
    name: "Avocados",
    description: "Ripe and ready to eat Hass avocados.",
    price: 4.99,
    unit: "bag of 4",
    image: "/placeholder.svg?height=150&width=150",
    categoryId: 2,
    popular: true,
  },
  {
    id: 203,
    name: "Organic Whole Milk",
    description: "Fresh organic whole milk from grass-fed cows.",
    price: 4.49,
    unit: "gallon",
    image: "/placeholder.svg?height=150&width=150",
    categoryId: 3,
    popular: true,
  },
  {
    id: 204,
    name: "Large Brown Eggs",
    description: "Farm fresh large brown eggs from free-range chickens.",
    price: 3.99,
    unit: "dozen",
    image: "/placeholder.svg?height=150&width=150",
    categoryId: 3,
    popular: false,
  },
  {
    id: 205,
    name: "Boneless Chicken Breast",
    description: "Hormone-free boneless, skinless chicken breasts.",
    price: 8.99,
    unit: "lb",
    image: "/placeholder.svg?height=150&width=150",
    categoryId: 4,
    popular: true,
  },
  {
    id: 206,
    name: "Atlantic Salmon Fillet",
    description: "Fresh Atlantic salmon fillet, sustainably sourced.",
    price: 12.99,
    unit: "lb",
    image: "/placeholder.svg?height=150&width=150",
    categoryId: 4,
    popular: false,
  },
  {
    id: 207,
    name: "Artisan Sourdough Bread",
    description: "Freshly baked artisan sourdough bread.",
    price: 5.49,
    unit: "loaf",
    image: "/placeholder.svg?height=150&width=150",
    categoryId: 5,
    popular: false,
  },
  {
    id: 208,
    name: "Sparkling Water",
    description: "Refreshing sparkling water, no sugar or artificial flavors.",
    price: 3.99,
    unit: "12-pack",
    image: "/placeholder.svg?height=150&width=150",
    categoryId: 6,
    popular: false,
  },
]

export default function GroceryStorePage({ params }: { params: { id: string } }) {
  const [activeCategory, setActiveCategory] = useState<number>(1)
  const [cartItems, setCartItems] = useState<{ id: number; quantity: number }[]>([])
  const [isFavorite, setIsFavorite] = useState(false)
  const { toast } = useToast()
  const { addToFoodCart, updateFoodQuantity, foodCartItems } = useFoodCart()

  const getProductsByCategory = (categoryId: number) => {
    if (categoryId === 1) {
      // Popular items
      return products.filter((item) => item.popular)
    }
    return products.filter((item) => item.categoryId === categoryId)
  }

  const handleAddToCart = (item: any) => {
    // Check if item is already in cart
    const existingItem = cartItems.find((cartItem) => cartItem.id === item.id)

    if (existingItem) {
      // Update quantity
      setCartItems(
        cartItems.map((cartItem) =>
          cartItem.id === item.id ? { ...cartItem, quantity: cartItem.quantity + 1 } : cartItem,
        ),
      )
    } else {
      // Add new item
      setCartItems([...cartItems, { id: item.id, quantity: 1 }])
    }

    // Add to food cart
    addToFoodCart({
      id: item.id,
      name: item.name,
      price: item.price,
      image: item.image,
      store: store.name,
      quantity: 1,
    })

    toast({
      title: "Added to Food Cart",
      description: `${item.name} has been added to your food cart.`,
    })
  }

  const handleRemoveFromCart = (itemId: number) => {
    // Update local cart
    const updatedItems = cartItems
      .map((item) => (item.id === itemId ? { ...item, quantity: item.quantity - 1 } : item))
      .filter((item) => item.quantity > 0)

    setCartItems(updatedItems)

    // Update food cart
    const foodItem = foodCartItems.find((item) => item.id === itemId)
    if (foodItem && foodItem.quantity > 1) {
      updateFoodQuantity(itemId, foodItem.quantity - 1)
    } else {
      updateFoodQuantity(itemId, 0) // This will remove the item
    }

    toast({
      title: "Updated Cart",
      description: "Item quantity has been updated.",
    })
  }

  const getItemQuantity = (itemId: number) => {
    const foodItem = foodCartItems.find((item) => item.id === itemId)
    return foodItem ? foodItem.quantity : 0
  }

  const toggleFavorite = () => {
    setIsFavorite(!isFavorite)
    toast({
      title: isFavorite ? "Removed from Favorites" : "Added to Favorites",
      description: `${store.name} has been ${isFavorite ? "removed from" : "added to"} your favorites.`,
    })
  }

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Store header */}
      <div className="relative mb-8 overflow-hidden rounded-xl">
        <div className="relative h-64 w-full">
          <Image src={store.image || "/placeholder.svg"} alt={store.name} fill className="object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
        </div>

        <div className="absolute bottom-0 left-0 w-full p-6 text-white">
          <div className="flex items-start justify-between">
            <div>
              <h1 className="text-3xl font-bold">{store.name}</h1>
              <p className="text-white/80">{store.type}</p>

              <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-2">
                <div className="flex items-center">
                  <Star className="mr-1 h-4 w-4 fill-yellow-400 text-yellow-400" />
                  <span>{store.rating}</span>
                  <span className="ml-1 text-white/60">({store.reviewCount})</span>
                </div>
                <div className="flex items-center">
                  <Clock className="mr-1 h-4 w-4" />
                  <span>{store.deliveryTime}</span>
                </div>
                <div className="flex items-center">
                  <DollarSign className="mr-1 h-4 w-4" />
                  <span>Min ₹{(store.minOrder * 80).toFixed(0)}</span>
                </div>
                <div className="flex items-center">
                  <MapPin className="mr-1 h-4 w-4" />
                  <span className="text-white/80">{store.address}</span>
                </div>
              </div>

              <div className="mt-2">
                <Badge variant={store.isOpen ? "default" : "destructive"}>{store.isOpen ? "Open Now" : "Closed"}</Badge>
                <span className="ml-2 text-sm text-white/80">{store.hours}</span>
              </div>
            </div>

            <div className="flex gap-2">
              <Button variant="secondary" size="icon" onClick={toggleFavorite}>
                <Heart className={`h-5 w-5 ${isFavorite ? "fill-red-500 text-red-500" : ""}`} />
                <span className="sr-only">Add to favorites</span>
              </Button>
              <Button variant="secondary" size="icon">
                <Share2 className="h-5 w-5" />
                <span className="sr-only">Share</span>
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Store info and products */}
      <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
        {/* Products */}
        <div className="lg:col-span-2">
          {/* Search */}
          <div className="mb-6">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input type="search" placeholder="Search products" className="pl-10" />
            </div>
          </div>

          {/* Product categories */}
          <div className="mb-6 overflow-x-auto">
            <div className="flex space-x-2 whitespace-nowrap">
              {productCategories.map((category) => (
                <Button
                  key={category.id}
                  variant={activeCategory === category.id ? "default" : "outline"}
                  onClick={() => setActiveCategory(category.id)}
                >
                  {category.name}
                </Button>
              ))}
            </div>
          </div>

          {/* Products */}
          <div className="space-y-6">
            {productCategories.map((category) => (
              <div
                key={category.id}
                id={`category-${category.id}`}
                className={activeCategory === category.id ? "block" : "hidden"}
              >
                <h2 className="mb-4 text-2xl font-bold">{category.name}</h2>
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  {getProductsByCategory(category.id).map((item) => (
                    <div key={item.id} className="flex gap-4 rounded-lg border p-4">
                      <div className="relative h-20 w-20 shrink-0 overflow-hidden rounded-md">
                        <Image src={item.image || "/placeholder.svg"} alt={item.name} fill className="object-cover" />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-start justify-between">
                          <div>
                            <h3 className="font-medium">{item.name}</h3>
                            <p className="text-sm text-muted-foreground">{item.description}</p>
                            <div className="mt-1 flex items-baseline gap-1">
                              <span className="font-medium">₹{(item.price * 80).toFixed(2)}</span>
                              <span className="text-xs text-muted-foreground">/ {item.unit}</span>
                            </div>
                          </div>
                          <div className="flex items-center">
                            {getItemQuantity(item.id) > 0 ? (
                              <div className="flex items-center rounded-md border">
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => handleRemoveFromCart(item.id)}
                                  className="h-8 w-8 rounded-none"
                                >
                                  <Minus className="h-3 w-3" />
                                  <span className="sr-only">Decrease quantity</span>
                                </Button>
                                <span className="flex h-8 w-8 items-center justify-center text-center text-sm">
                                  {getItemQuantity(item.id)}
                                </span>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => handleAddToCart(item)}
                                  className="h-8 w-8 rounded-none"
                                >
                                  <Plus className="h-3 w-3" />
                                  <span className="sr-only">Increase quantity</span>
                                </Button>
                              </div>
                            ) : (
                              <Button size="sm" onClick={() => handleAddToCart(item)}>
                                <Plus className="mr-1 h-4 w-4" />
                                Add
                              </Button>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Order summary */}
        <div className="lg:col-span-1">
          <div className="sticky top-20 rounded-lg border p-6">
            <h2 className="mb-4 text-lg font-semibold">Delivery Details</h2>

            <div className="mb-4 space-y-4">
              <div className="flex items-start gap-3">
                <MapPin className="mt-0.5 h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="font-medium">Delivery Address</p>
                  <p className="text-sm text-muted-foreground">123 Main St, Anytown</p>
                  <Button variant="link" className="h-auto p-0 text-sm">
                    Change
                  </Button>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Clock className="mt-0.5 h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="font-medium">Delivery Time</p>
                  <p className="text-sm text-muted-foreground">ASAP ({store.deliveryTime})</p>
                  <Button variant="link" className="h-auto p-0 text-sm">
                    Schedule for later
                  </Button>
                </div>
              </div>
            </div>

            <Separator className="my-4" />

            <div className="mb-4">
              <h3 className="mb-2 font-medium">Special Instructions</h3>
              <Input placeholder="Add notes for the store" />
            </div>

            <Separator className="my-4" />

            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Subtotal</span>
                <span>
                  ₹
                  {foodCartItems
                    .filter((item) => item.store === store.name)
                    .reduce((total, item) => total + item.price * item.quantity * 80, 0)
                    .toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Delivery Fee</span>
                <span>₹{(store.deliveryFee * 80).toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Tax</span>
                <span>
                  ₹
                  {(
                    foodCartItems
                      .filter((item) => item.store === store.name)
                      .reduce((total, item) => total + item.price * item.quantity * 80, 0) * 0.08
                  ).toFixed(2)}
                </span>
              </div>

              <Separator className="my-2" />

              <div className="flex justify-between font-medium">
                <span>Total</span>
                <span>
                  ₹
                  {(
                    foodCartItems
                      .filter((item) => item.store === store.name)
                      .reduce((total, item) => total + item.price * item.quantity * 80, 0) +
                    store.deliveryFee * 80 +
                    foodCartItems
                      .filter((item) => item.store === store.name)
                      .reduce((total, item) => total + item.price * item.quantity * 80, 0) *
                      0.08
                  ).toFixed(2)}
                </span>
              </div>
            </div>

            <Button
              className="mt-6 w-full"
              disabled={
                foodCartItems.filter((item) => item.store === store.name).length === 0 ||
                !store.isOpen ||
                foodCartItems
                  .filter((item) => item.store === store.name)
                  .reduce((total, item) => total + item.price * item.quantity * 80, 0) <
                  store.minOrder * 80
              }
              asChild
            >
              <Link href="/food/cart">
                {foodCartItems.filter((item) => item.store === store.name).length === 0
                  ? "Add items to proceed"
                  : !store.isOpen
                    ? "Store is closed"
                    : foodCartItems
                          .filter((item) => item.store === store.name)
                          .reduce((total, item) => total + item.price * item.quantity * 80, 0) <
                        store.minOrder * 80
                      ? `Minimum order: ₹${(store.minOrder * 80).toFixed(0)}`
                      : "Proceed to Checkout"}
              </Link>
            </Button>

            {!store.isOpen && (
              <p className="mt-2 text-center text-sm text-muted-foreground">
                This store is currently closed. Please check back during operating hours.
              </p>
            )}

            {foodCartItems.filter((item) => item.store === store.name).length > 0 &&
              store.isOpen &&
              foodCartItems
                .filter((item) => item.store === store.name)
                .reduce((total, item) => total + item.price * item.quantity * 80, 0) <
                store.minOrder * 80 && (
                <p className="mt-2 text-center text-sm text-muted-foreground">
                  Add ₹
                  {(
                    store.minOrder * 80 -
                    foodCartItems
                      .filter((item) => item.store === store.name)
                      .reduce((total, item) => total + item.price * item.quantity * 80, 0)
                  ).toFixed(2)}{" "}
                  more to meet the minimum order amount.
                </p>
              )}

            {foodCartItems.filter((item) => item.store === store.name).length > 0 &&
              store.isOpen &&
              foodCartItems
                .filter((item) => item.store === store.name)
                .reduce((total, item) => total + item.price * item.quantity * 80, 0) >=
                store.minOrder * 80 && (
                <p className="mt-2 text-center text-sm text-muted-foreground">
                  Estimated delivery time: {store.deliveryTime}
                </p>
              )}
          </div>
        </div>
      </div>

      {/* Store info */}
      <div className="mt-12">
        <h2 className="mb-4 text-2xl font-bold">About {store.name}</h2>
        <div className="rounded-lg border p-6">
          <p className="text-muted-foreground">{store.description}</p>

          <div className="mt-6 grid grid-cols-1 gap-6 sm:grid-cols-2">
            <div>
              <h3 className="mb-2 font-medium">Hours of Operation</h3>
              <p className="text-muted-foreground">{store.hours}</p>
            </div>
            <div>
              <h3 className="mb-2 font-medium">Address</h3>
              <p className="text-muted-foreground">{store.address}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
