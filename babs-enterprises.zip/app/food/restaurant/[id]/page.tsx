"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Star, Clock, DollarSign, MapPin, Plus, Minus, Heart, Share2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Separator } from "@/components/ui/separator"
import { useToast } from "@/hooks/use-toast"
import { useFoodCart } from "@/lib/food-cart-context"

// Mock restaurant data
const restaurant = {
  id: 1,
  name: "Burger Palace",
  image: "/placeholder.svg?height=300&width=800",
  cuisine: "American",
  rating: 4.7,
  reviewCount: 253,
  deliveryTime: "15-25 min",
  deliveryFee: 2.99, // Base price in USD, displayed in INR
  minOrder: 10, // Base price in USD, displayed in INR
  address: "123 Main St, Anytown",
  description:
    "Serving the juiciest burgers in town since 2010. Our burgers are made with 100% Angus beef and fresh ingredients.",
  hours: "10:00 AM - 10:00 PM",
  isOpen: true,
}

// Mock menu categories
const menuCategories = [
  { id: 1, name: "Popular Items" },
  { id: 2, name: "Burgers" },
  { id: 3, name: "Sides" },
  { id: 4, name: "Drinks" },
  { id: 5, name: "Desserts" },
]

// Mock menu items
const menuItems = [
  {
    id: 101,
    name: "Classic Cheeseburger",
    description:
      "Angus beef patty, cheddar cheese, lettuce, tomato, onion, pickles, and our special sauce on a brioche bun.",
    price: 8.99,
    image: "/placeholder.svg?height=150&width=150",
    categoryId: 2,
    popular: true,
  },
  {
    id: 102,
    name: "Bacon Deluxe Burger",
    description:
      "Angus beef patty, crispy bacon, cheddar cheese, lettuce, tomato, onion, and BBQ sauce on a brioche bun.",
    price: 10.99,
    image: "/placeholder.svg?height=150&width=150",
    categoryId: 2,
    popular: true,
  },
  {
    id: 103,
    name: "Veggie Burger",
    description: "Plant-based patty, lettuce, tomato, onion, pickles, and vegan mayo on a whole grain bun.",
    price: 9.99,
    image: "/placeholder.svg?height=150&width=150",
    categoryId: 2,
    popular: false,
  },
  {
    id: 104,
    name: "French Fries",
    description: "Crispy golden fries seasoned with sea salt.",
    price: 3.99,
    image: "/placeholder.svg?height=150&width=150",
    categoryId: 3,
    popular: true,
  },
  {
    id: 105,
    name: "Onion Rings",
    description: "Crispy battered onion rings served with dipping sauce.",
    price: 4.99,
    image: "/placeholder.svg?height=150&width=150",
    categoryId: 3,
    popular: false,
  },
  {
    id: 106,
    name: "Soft Drink",
    description: "Your choice of soda, 16oz cup.",
    price: 2.49,
    image: "/placeholder.svg?height=150&width=150",
    categoryId: 4,
    popular: false,
  },
  {
    id: 107,
    name: "Milkshake",
    description: "Creamy milkshake made with premium ice cream. Available in chocolate, vanilla, or strawberry.",
    price: 5.99,
    image: "/placeholder.svg?height=150&width=150",
    categoryId: 4,
    popular: true,
  },
  {
    id: 108,
    name: "Chocolate Brownie",
    description: "Warm chocolate brownie topped with vanilla ice cream and chocolate sauce.",
    price: 6.99,
    image: "/placeholder.svg?height=150&width=150",
    categoryId: 5,
    popular: false,
  },
]

export default function RestaurantPage({ params }: { params: { id: string } }) {
  const [activeCategory, setActiveCategory] = useState<number>(1)
  const [cartItems, setCartItems] = useState<{ id: number; quantity: number }[]>([])
  const [isFavorite, setIsFavorite] = useState(false)
  const { toast } = useToast()
  const { addToFoodCart, updateFoodQuantity, foodCartItems } = useFoodCart()

  const getMenuItemsByCategory = (categoryId: number) => {
    if (categoryId === 1) {
      // Popular items
      return menuItems.filter((item) => item.popular)
    }
    return menuItems.filter((item) => item.categoryId === categoryId)
  }

  const handleAddToCart = (item: any) => {
    // Check if item is already in cart
    const existingItem = cartItems.find((cartItem) => cartItem.id === item.id)

    if (existingItem) {
      // Update quantity
      setCartItems(
        cartItems.map((cartItem) =>
          cartItem.id === item.id ? { ...cartItem, quantity: cartItem.quantity + 1 } : cartItem,
        ),
      )
    } else {
      // Add new item
      setCartItems([...cartItems, { id: item.id, quantity: 1 }])
    }

    // Add to food cart
    addToFoodCart({
      id: item.id,
      name: item.name,
      price: item.price,
      image: item.image,
      restaurant: restaurant.name,
      quantity: 1,
    })

    toast({
      title: "Added to Food Cart",
      description: `${item.name} has been added to your food cart.`,
    })
  }

  const handleRemoveFromCart = (itemId: number) => {
    // Update local cart
    const updatedItems = cartItems
      .map((item) => (item.id === itemId ? { ...item, quantity: item.quantity - 1 } : item))
      .filter((item) => item.quantity > 0)

    setCartItems(updatedItems)

    // Update food cart
    const foodItem = foodCartItems.find((item) => item.id === itemId)
    if (foodItem && foodItem.quantity > 1) {
      updateFoodQuantity(itemId, foodItem.quantity - 1)
    } else {
      updateFoodQuantity(itemId, 0) // This will remove the item
    }

    toast({
      title: "Updated Cart",
      description: "Item quantity has been updated.",
    })
  }

  const getItemQuantity = (itemId: number) => {
    const foodItem = foodCartItems.find((item) => item.id === itemId)
    return foodItem ? foodItem.quantity : 0
  }

  const toggleFavorite = () => {
    setIsFavorite(!isFavorite)
    toast({
      title: isFavorite ? "Removed from Favorites" : "Added to Favorites",
      description: `${restaurant.name} has been ${isFavorite ? "removed from" : "added to"} your favorites.`,
    })
  }

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Restaurant header */}
      <div className="relative mb-8 overflow-hidden rounded-xl">
        <div className="relative h-64 w-full">
          <Image src={restaurant.image || "/placeholder.svg"} alt={restaurant.name} fill className="object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
        </div>

        <div className="absolute bottom-0 left-0 w-full p-6 text-white">
          <div className="flex items-start justify-between">
            <div>
              <h1 className="text-3xl font-bold">{restaurant.name}</h1>
              <p className="text-white/80">{restaurant.cuisine}</p>

              <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-2">
                <div className="flex items-center">
                  <Star className="mr-1 h-4 w-4 fill-yellow-400 text-yellow-400" />
                  <span>{restaurant.rating}</span>
                  <span className="ml-1 text-white/60">({restaurant.reviewCount})</span>
                </div>
                <div className="flex items-center">
                  <Clock className="mr-1 h-4 w-4" />
                  <span>{restaurant.deliveryTime}</span>
                </div>
                <div className="flex items-center">
                  <DollarSign className="mr-1 h-4 w-4" />
                  <span>Min ₹{(restaurant.minOrder * 80).toFixed(0)}</span>
                </div>
                <div className="flex items-center">
                  <MapPin className="mr-1 h-4 w-4" />
                  <span className="text-white/80">{restaurant.address}</span>
                </div>
              </div>

              <div className="mt-2">
                <Badge variant={restaurant.isOpen ? "default" : "destructive"}>
                  {restaurant.isOpen ? "Open Now" : "Closed"}
                </Badge>
                <span className="ml-2 text-sm text-white/80">{restaurant.hours}</span>
              </div>
            </div>

            <div className="flex gap-2">
              <Button variant="secondary" size="icon" onClick={toggleFavorite}>
                <Heart className={`h-5 w-5 ${isFavorite ? "fill-red-500 text-red-500" : ""}`} />
                <span className="sr-only">Add to favorites</span>
              </Button>
              <Button variant="secondary" size="icon">
                <Share2 className="h-5 w-5" />
                <span className="sr-only">Share</span>
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Restaurant info and menu */}
      <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
        {/* Menu */}
        <div className="lg:col-span-2">
          {/* Search */}
          <div className="mb-6">
            <Input type="search" placeholder="Search menu items" className="w-full" />
          </div>

          {/* Menu categories */}
          <div className="mb-6 overflow-x-auto">
            <div className="flex space-x-2 whitespace-nowrap">
              {menuCategories.map((category) => (
                <Button
                  key={category.id}
                  variant={activeCategory === category.id ? "default" : "outline"}
                  onClick={() => setActiveCategory(category.id)}
                >
                  {category.name}
                </Button>
              ))}
            </div>
          </div>

          {/* Menu items */}
          <div className="space-y-6">
            {menuCategories.map((category) => (
              <div
                key={category.id}
                id={`category-${category.id}`}
                className={activeCategory === category.id ? "block" : "hidden"}
              >
                <h2 className="mb-4 text-2xl font-bold">{category.name}</h2>
                <div className="space-y-4">
                  {getMenuItemsByCategory(category.id).map((item) => (
                    <div key={item.id} className="flex gap-4 rounded-lg border p-4">
                      <div className="relative h-20 w-20 shrink-0 overflow-hidden rounded-md">
                        <Image src={item.image || "/placeholder.svg"} alt={item.name} fill className="object-cover" />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-start justify-between">
                          <div>
                            <h3 className="font-medium">{item.name}</h3>
                            <p className="text-sm text-muted-foreground">{item.description}</p>
                            <p className="mt-1 font-medium">₹{(item.price * 80).toFixed(2)}</p>
                          </div>
                          <div className="flex items-center">
                            {getItemQuantity(item.id) > 0 ? (
                              <div className="flex items-center rounded-md border">
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => handleRemoveFromCart(item.id)}
                                  className="h-8 w-8 rounded-none"
                                >
                                  <Minus className="h-3 w-3" />
                                  <span className="sr-only">Decrease quantity</span>
                                </Button>
                                <span className="flex h-8 w-8 items-center justify-center text-center text-sm">
                                  {getItemQuantity(item.id)}
                                </span>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => handleAddToCart(item)}
                                  className="h-8 w-8 rounded-none"
                                >
                                  <Plus className="h-3 w-3" />
                                  <span className="sr-only">Increase quantity</span>
                                </Button>
                              </div>
                            ) : (
                              <Button size="sm" onClick={() => handleAddToCart(item)}>
                                <Plus className="mr-1 h-4 w-4" />
                                Add
                              </Button>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Order summary */}
        <div className="lg:col-span-1">
          <div className="sticky top-20 rounded-lg border p-6">
            <h2 className="mb-4 text-lg font-semibold">Delivery Details</h2>

            <div className="mb-4 space-y-4">
              <div className="flex items-start gap-3">
                <MapPin className="mt-0.5 h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="font-medium">Delivery Address</p>
                  <p className="text-sm text-muted-foreground">123 Main St, Anytown</p>
                  <Button variant="link" className="h-auto p-0 text-sm">
                    Change
                  </Button>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Clock className="mt-0.5 h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="font-medium">Delivery Time</p>
                  <p className="text-sm text-muted-foreground">ASAP (15-25 min)</p>
                  <Button variant="link" className="h-auto p-0 text-sm">
                    Schedule for later
                  </Button>
                </div>
              </div>
            </div>

            <Separator className="my-4" />

            <div className="mb-4">
              <h3 className="mb-2 font-medium">Special Instructions</h3>
              <Input placeholder="Add notes for the restaurant" />
            </div>

            <Separator className="my-4" />

            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Subtotal</span>
                <span>
                  ₹
                  {foodCartItems
                    .filter((item) => item.restaurant === restaurant.name)
                    .reduce((total, item) => total + item.price * item.quantity, 0)
                    .toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Delivery Fee</span>
                <span>₹{(restaurant.deliveryFee * 80).toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Tax</span>
                <span>
                  ₹
                  {(
                    foodCartItems
                      .filter((item) => item.restaurant === restaurant.name)
                      .reduce((total, item) => total + item.price * item.quantity, 0) * 0.08
                  ).toFixed(2)}
                </span>
              </div>

              <Separator className="my-2" />

              <div className="flex justify-between font-medium">
                <span>Total</span>
                <span>
                  ₹
                  {(
                    foodCartItems
                      .filter((item) => item.restaurant === restaurant.name)
                      .reduce((total, item) => total + item.price * item.quantity, 0) +
                    restaurant.deliveryFee +
                    foodCartItems
                      .filter((item) => item.restaurant === restaurant.name)
                      .reduce((total, item) => total + item.price * item.quantity, 0) *
                      0.08
                  ).toFixed(2)}
                </span>
              </div>
            </div>

            <Button
              className="mt-6 w-full"
              disabled={
                foodCartItems.filter((item) => item.restaurant === restaurant.name).length === 0 || !restaurant.isOpen
              }
              asChild
            >
              <Link href="/food/cart">
                {foodCartItems.filter((item) => item.restaurant === restaurant.name).length === 0
                  ? "Add items to proceed"
                  : !restaurant.isOpen
                    ? "Restaurant is closed"
                    : "Proceed to Checkout"}
              </Link>
            </Button>

            {!restaurant.isOpen && (
              <p className="mt-2 text-center text-sm text-muted-foreground">
                This restaurant is currently closed. Please check back during operating hours.
              </p>
            )}

            {foodCartItems.filter((item) => item.restaurant === restaurant.name).length > 0 && restaurant.isOpen && (
              <p className="mt-2 text-center text-sm text-muted-foreground">
                Estimated delivery time: {restaurant.deliveryTime}
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Restaurant info */}
      <div className="mt-12">
        <h2 className="mb-4 text-2xl font-bold">About {restaurant.name}</h2>
        <div className="rounded-lg border p-6">
          <p className="text-muted-foreground">{restaurant.description}</p>

          <div className="mt-6 grid grid-cols-1 gap-6 sm:grid-cols-2">
            <div>
              <h3 className="mb-2 font-medium">Hours of Operation</h3>
              <p className="text-muted-foreground">{restaurant.hours}</p>
            </div>
            <div>
              <h3 className="mb-2 font-medium">Address</h3>
              <p className="text-muted-foreground">{restaurant.address}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
