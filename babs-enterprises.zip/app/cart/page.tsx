"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Trash2, Minus, Plus, ArrowRight, ShoppingBag, Store, Utensils } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useCart } from "@/lib/cart-context"
import { useToast } from "@/hooks/use-toast"

export default function CartPage() {
  const { cartItems, removeFromCart, updateQuantity, subtotal } = useCart()
  const { toast } = useToast()
  const [promoCode, setPromoCode] = useState("")

  const shipping = 0 // Free shipping
  const tax = subtotal * 0.08 // 8% tax
  const total = subtotal + shipping + tax

  // Group cart items by type (products, food, grocery)
  const productItems = cartItems.filter((item) => !item.restaurant && !item.store)
  const foodItems = cartItems.filter((item) => item.restaurant)
  const groceryItems = cartItems.filter((item) => item.store)

  const handleApplyPromo = () => {
    if (!promoCode) {
      toast({
        title: "Error",
        description: "Please enter a promo code.",
        variant: "destructive",
      })
      return
    }

    toast({
      title: "Invalid Code",
      description: "The promo code you entered is invalid or expired.",
      variant: "destructive",
    })
  }

  const handleCheckout = () => {
    if (cartItems.length === 0) {
      toast({
        title: "Empty Cart",
        description: "Your cart is empty. Add some items before checkout.",
        variant: "destructive",
      })
      return
    }

    // In a real app, this would navigate to checkout
    toast({
      title: "Checkout",
      description: "This is a mock checkout for a school project. No real transactions will occur.",
    })
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="mb-8 text-3xl font-bold">Your Cart</h1>

      {cartItems.length === 0 ? (
        <div className="flex flex-col items-center justify-center rounded-lg border py-16">
          <ShoppingBag className="mb-4 h-16 w-16 text-muted-foreground" />
          <h2 className="mb-2 text-xl font-semibold">Your cart is empty</h2>
          <p className="mb-6 text-muted-foreground">Looks like you haven't added anything to your cart yet.</p>
          <Button asChild>
            <Link href="/products">Browse Products</Link>
          </Button>
        </div>
      ) : (
        <div className="grid gap-8 lg:grid-cols-3">
          {/* Cart Items */}
          <div className="lg:col-span-2">
            <Tabs defaultValue={productItems.length > 0 ? "products" : foodItems.length > 0 ? "food" : "grocery"}>
              <TabsList className="mb-4 grid w-full grid-cols-3">
                <TabsTrigger value="products" disabled={productItems.length === 0}>
                  Products {productItems.length > 0 && `(${productItems.length})`}
                </TabsTrigger>
                <TabsTrigger value="food" disabled={foodItems.length === 0}>
                  Food {foodItems.length > 0 && `(${foodItems.length})`}
                </TabsTrigger>
                <TabsTrigger value="grocery" disabled={groceryItems.length === 0}>
                  Grocery {groceryItems.length > 0 && `(${groceryItems.length})`}
                </TabsTrigger>
              </TabsList>

              <TabsContent value="products">
                <div className="rounded-lg border">
                  <div className="grid grid-cols-12 gap-4 p-4 text-sm font-medium text-muted-foreground">
                    <div className="col-span-6">Product</div>
                    <div className="col-span-2 text-center">Price</div>
                    <div className="col-span-2 text-center">Quantity</div>
                    <div className="col-span-2 text-right">Total</div>
                  </div>
                  <Separator />

                  {productItems.map((item) => (
                    <div key={item.id}>
                      <div className="grid grid-cols-12 items-center gap-4 p-4">
                        <div className="col-span-6 flex items-center gap-4">
                          <div className="relative h-16 w-16 overflow-hidden rounded-md border">
                            <Image
                              src={item.image || "/placeholder.svg"}
                              alt={item.name}
                              fill
                              className="object-cover"
                            />
                          </div>
                          <div>
                            <h3 className="font-medium">
                              <Link href={`/product/${item.id}`} className="hover:underline">
                                {item.name}
                              </Link>
                            </h3>
                            <p className="mt-1 text-xs text-muted-foreground">{item.category}</p>
                          </div>
                        </div>

                        <div className="col-span-2 text-center">₹{(item.price * 80).toFixed(2)}</div>

                        <div className="col-span-2 flex justify-center">
                          <div className="flex items-center rounded-md border">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => updateQuantity(item.id, item.quantity - 1)}
                              className="h-8 w-8 rounded-none"
                            >
                              <Minus className="h-3 w-3" />
                              <span className="sr-only">Decrease quantity</span>
                            </Button>
                            <span className="flex h-8 w-8 items-center justify-center text-center text-sm">
                              {item.quantity}
                            </span>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => updateQuantity(item.id, item.quantity + 1)}
                              className="h-8 w-8 rounded-none"
                            >
                              <Plus className="h-3 w-3" />
                              <span className="sr-only">Increase quantity</span>
                            </Button>
                          </div>
                        </div>

                        <div className="col-span-2 flex items-center justify-end gap-2">
                          <span className="font-medium">₹{(item.price * item.quantity * 80).toFixed(2)}</span>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => removeFromCart(item.id)}
                            className="h-8 w-8 text-muted-foreground hover:text-destructive"
                          >
                            <Trash2 className="h-4 w-4" />
                            <span className="sr-only">Remove item</span>
                          </Button>
                        </div>
                      </div>
                      <Separator />
                    </div>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="food">
                <div className="rounded-lg border">
                  {foodItems.length > 0 && (
                    <>
                      <div className="grid grid-cols-12 gap-4 p-4 text-sm font-medium text-muted-foreground">
                        <div className="col-span-6">Item</div>
                        <div className="col-span-2 text-center">Price</div>
                        <div className="col-span-2 text-center">Quantity</div>
                        <div className="col-span-2 text-right">Total</div>
                      </div>
                      <Separator />
                    </>
                  )}

                  {/* Group food items by restaurant */}
                  {Array.from(new Set(foodItems.map((item) => item.restaurant))).map((restaurant) => (
                    <div key={restaurant}>
                      <div className="bg-muted/30 p-3">
                        <div className="flex items-center gap-2">
                          <Utensils className="h-4 w-4 text-muted-foreground" />
                          <h3 className="font-medium">{restaurant}</h3>
                        </div>
                      </div>

                      {foodItems
                        .filter((item) => item.restaurant === restaurant)
                        .map((item) => (
                          <div key={item.id}>
                            <div className="grid grid-cols-12 items-center gap-4 p-4">
                              <div className="col-span-6 flex items-center gap-4">
                                <div className="relative h-16 w-16 overflow-hidden rounded-md border">
                                  <Image
                                    src={item.image || "/placeholder.svg"}
                                    alt={item.name}
                                    fill
                                    className="object-cover"
                                  />
                                </div>
                                <div>
                                  <h3 className="font-medium">{item.name}</h3>
                                  <p className="mt-1 text-xs text-muted-foreground">From {item.restaurant}</p>
                                </div>
                              </div>

                              <div className="col-span-2 text-center">₹{(item.price * 80).toFixed(2)}</div>

                              <div className="col-span-2 flex justify-center">
                                <div className="flex items-center rounded-md border">
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => updateQuantity(item.id, item.quantity - 1)}
                                    className="h-8 w-8 rounded-none"
                                  >
                                    <Minus className="h-3 w-3" />
                                    <span className="sr-only">Decrease quantity</span>
                                  </Button>
                                  <span className="flex h-8 w-8 items-center justify-center text-center text-sm">
                                    {item.quantity}
                                  </span>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => updateQuantity(item.id, item.quantity + 1)}
                                    className="h-8 w-8 rounded-none"
                                  >
                                    <Plus className="h-3 w-3" />
                                    <span className="sr-only">Increase quantity</span>
                                  </Button>
                                </div>
                              </div>

                              <div className="col-span-2 flex items-center justify-end gap-2">
                                <span className="font-medium">₹{(item.price * item.quantity * 80).toFixed(2)}</span>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => removeFromCart(item.id)}
                                  className="h-8 w-8 text-muted-foreground hover:text-destructive"
                                >
                                  <Trash2 className="h-4 w-4" />
                                  <span className="sr-only">Remove item</span>
                                </Button>
                              </div>
                            </div>
                            <Separator />
                          </div>
                        ))}
                    </div>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="grocery">
                <div className="rounded-lg border">
                  {groceryItems.length > 0 && (
                    <>
                      <div className="grid grid-cols-12 gap-4 p-4 text-sm font-medium text-muted-foreground">
                        <div className="col-span-6">Item</div>
                        <div className="col-span-2 text-center">Price</div>
                        <div className="col-span-2 text-center">Quantity</div>
                        <div className="col-span-2 text-right">Total</div>
                      </div>
                      <Separator />
                    </>
                  )}

                  {/* Group grocery items by store */}
                  {Array.from(new Set(groceryItems.map((item) => item.store))).map((store) => (
                    <div key={store}>
                      <div className="bg-muted/30 p-3">
                        <div className="flex items-center gap-2">
                          <Store className="h-4 w-4 text-muted-foreground" />
                          <h3 className="font-medium">{store}</h3>
                        </div>
                      </div>

                      {groceryItems
                        .filter((item) => item.store === store)
                        .map((item) => (
                          <div key={item.id}>
                            <div className="grid grid-cols-12 items-center gap-4 p-4">
                              <div className="col-span-6 flex items-center gap-4">
                                <div className="relative h-16 w-16 overflow-hidden rounded-md border">
                                  <Image
                                    src={item.image || "/placeholder.svg"}
                                    alt={item.name}
                                    fill
                                    className="object-cover"
                                  />
                                </div>
                                <div>
                                  <h3 className="font-medium">{item.name}</h3>
                                  <p className="mt-1 text-xs text-muted-foreground">From {item.store}</p>
                                </div>
                              </div>

                              <div className="col-span-2 text-center">₹{(item.price * 80).toFixed(2)}</div>

                              <div className="col-span-2 flex justify-center">
                                <div className="flex items-center rounded-md border">
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => updateQuantity(item.id, item.quantity - 1)}
                                    className="h-8 w-8 rounded-none"
                                  >
                                    <Minus className="h-3 w-3" />
                                    <span className="sr-only">Decrease quantity</span>
                                  </Button>
                                  <span className="flex h-8 w-8 items-center justify-center text-center text-sm">
                                    {item.quantity}
                                  </span>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => updateQuantity(item.id, item.quantity + 1)}
                                    className="h-8 w-8 rounded-none"
                                  >
                                    <Plus className="h-3 w-3" />
                                    <span className="sr-only">Increase quantity</span>
                                  </Button>
                                </div>
                              </div>

                              <div className="col-span-2 flex items-center justify-end gap-2">
                                <span className="font-medium">₹{(item.price * item.quantity * 80).toFixed(2)}</span>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => removeFromCart(item.id)}
                                  className="h-8 w-8 text-muted-foreground hover:text-destructive"
                                >
                                  <Trash2 className="h-4 w-4" />
                                  <span className="sr-only">Remove item</span>
                                </Button>
                              </div>
                            </div>
                            <Separator />
                          </div>
                        ))}
                    </div>
                  ))}
                </div>
              </TabsContent>
            </Tabs>

            <div className="mt-4 flex justify-between">
              <Button variant="outline" asChild>
                <Link href="/products">Continue Shopping</Link>
              </Button>
              <Button variant="outline" asChild>
                <Link href="/food">Browse Food & Grocery</Link>
              </Button>
            </div>
          </div>

          {/* Order Summary */}
          <div>
            <div className="rounded-lg border p-6">
              <h2 className="mb-4 text-lg font-semibold">Order Summary</h2>

              <div className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Subtotal</span>
                  <span>₹{(subtotal * 80).toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Shipping</span>
                  <span>{shipping === 0 ? "Free" : `₹${(shipping * 80).toFixed(2)}`}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Tax (8%)</span>
                  <span>₹{(tax * 80).toFixed(2)}</span>
                </div>

                <Separator />

                <div className="flex justify-between font-medium">
                  <span>Total</span>
                  <span>₹{(total * 80).toFixed(2)}</span>
                </div>

                <div className="pt-4">
                  <div className="mb-2 flex gap-2">
                    <Input placeholder="Promo code" value={promoCode} onChange={(e) => setPromoCode(e.target.value)} />
                    <Button variant="outline" onClick={handleApplyPromo}>
                      Apply
                    </Button>
                  </div>

                  <Button className="mt-4 w-full" onClick={handleCheckout}>
                    Checkout
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>

                  <p className="mt-4 text-center text-xs text-muted-foreground">
                    This is a mock checkout for a school project. No real transactions will occur.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
