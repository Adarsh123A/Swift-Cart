"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

interface FoodItem {
  id: number
  name: string
  price: number
  image: string
  quantity?: number
  restaurant?: string
  store?: string
}

interface FoodCartItem extends FoodItem {
  quantity: number
}

interface FoodCartContextType {
  foodCartItems: FoodCartItem[]
  addToFoodCart: (item: FoodItem) => void
  removeFromFoodCart: (itemId: number) => void
  updateFoodQuantity: (itemId: number, quantity: number) => void
  clearFoodCart: () => void
  totalFoodItems: number
  foodSubtotal: number
}

const FoodCartContext = createContext<FoodCartContextType | undefined>(undefined)

export function FoodCartProvider({ children }: { children: ReactNode }) {
  const [foodCartItems, setFoodCartItems] = useState<FoodCartItem[]>([])

  // Load food cart from localStorage on initial render
  useEffect(() => {
    const savedCart = localStorage.getItem("foodCart")
    if (savedCart) {
      try {
        setFoodCartItems(JSON.parse(savedCart))
      } catch (error) {
        console.error("Failed to parse food cart from localStorage:", error)
      }
    }
  }, [])

  // Save food cart to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem("foodCart", JSON.stringify(foodCartItems))
  }, [foodCartItems])

  const addToFoodCart = (item: FoodItem) => {
    setFoodCartItems((prevItems) => {
      const existingItem = prevItems.find((cartItem) => cartItem.id === item.id)

      if (existingItem) {
        return prevItems.map((cartItem) =>
          cartItem.id === item.id ? { ...cartItem, quantity: cartItem.quantity + 1 } : cartItem,
        )
      } else {
        return [...prevItems, { ...item, quantity: 1 }]
      }
    })
  }

  const removeFromFoodCart = (itemId: number) => {
    setFoodCartItems((prevItems) => prevItems.filter((item) => item.id !== itemId))
  }

  const updateFoodQuantity = (itemId: number, quantity: number) => {
    if (quantity <= 0) {
      removeFromFoodCart(itemId)
      return
    }

    setFoodCartItems((prevItems) => prevItems.map((item) => (item.id === itemId ? { ...item, quantity } : item)))
  }

  const clearFoodCart = () => {
    setFoodCartItems([])
  }

  const totalFoodItems = foodCartItems.reduce((total, item) => total + item.quantity, 0)

  const foodSubtotal = foodCartItems.reduce((total, item) => total + item.price * item.quantity, 0)

  return (
    <FoodCartContext.Provider
      value={{
        foodCartItems,
        addToFoodCart,
        removeFromFoodCart,
        updateFoodQuantity,
        clearFoodCart,
        totalFoodItems,
        foodSubtotal,
      }}
    >
      {children}
    </FoodCartContext.Provider>
  )
}

export function useFoodCart() {
  const context = useContext(FoodCartContext)
  if (context === undefined) {
    throw new Error("useFoodCart must be used within a FoodCartProvider")
  }
  return context
}
